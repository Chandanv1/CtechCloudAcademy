import { sb, configured } from './supabase.js';
import { $, $$, esc, inr, CATS, animateCount, param, link } from './main.js';

const ICON = { 'Data Engineering': '🗄️', 'Data Analytics': '📊', 'Cloud Computing': '☁️', 'AI & Machine Learning': '🤖', 'Full-Stack & Technology Stacks': '💻' };

export async function fetchCourses() {
  if (!configured) throw new Error('Supabase is not configured');
  const { data, error } = await sb.from('courses').select('*').eq('is_published', true).order('category').order('name');
  if (error) throw error;
  return data || [];
}

const final = c => c.fee_inr - c.discount_inr;
const priceHtml = c => `<div class="price">${inr(final(c))}${c.discount_inr > 0 ? `<s>${inr(c.fee_inr)}</s>` : ''}</div>`;
const curr = c => (Array.isArray(c.curriculum) && c.curriculum.length ? c.curriculum.slice(0, 3).join(', ') : 'Curriculum overview to be published');

export function card(c) {
  return `<article class="card course reveal in" data-name="${esc(c.name.toLowerCase())}" data-cat="${esc(c.category)}" data-level="${esc(c.skill_level)}">
<div class="thumb" aria-hidden="true">${ICON[c.category] || '🎓'}</div><div class="meta"><span class="chip">${esc(c.category)}</span><span class="chip">${esc(c.skill_level)}</span></div>
<h3>${esc(c.name)}</h3><p>${esc(c.description)}</p>
<dl><span class="row"><dt>Duration: </dt><dd>${esc(c.duration)}</dd></span><span class="row"><dt>Mode: </dt><dd>${esc(c.delivery_mode)}</dd></span><span class="row"><dt>Curriculum: </dt><dd>${esc(curr(c))}</dd></span><span class="row"><dt>Prerequisites: </dt><dd>${esc(c.prerequisites)}</dd></span><span class="row"><dt>Projects: </dt><dd>${esc(c.projects)}</dd></span></dl>
${priceHtml(c)}<div class="actions"><a class="btn btn-primary btn-sm" href="${link('enroll.html', 'course', c.id)}">Enroll Now</a><a class="btn btn-ghost btn-sm" href="${link('course-details.html', 'slug', c.slug)}">View Details</a></div></article>`;
}

const empty = m => `<p class="empty">${m}</p>`;

async function index() {
  const cs = await fetchCourses();
  $('#featured-courses').innerHTML = cs.length ? cs.slice(0, 6).map(card).join('') : empty('Courses will appear here once published.');
  animateCount($('#stat-courses'), cs.length);
  animateCount($('#stat-tracks'), new Set(cs.map(c => c.category)).size);
}

async function list() {
  const cs = await fetchCourses(), g = $('#course-grid'), q = $('#q'), cat = $('#cat'), lv = $('#level');
  cat.innerHTML = '<option value="">All categories</option>' + CATS.map(c => `<option>${esc(c)}</option>`).join('');
  lv.innerHTML = '<option value="">All levels</option>' + [...new Set(cs.map(c => c.skill_level))].map(l => `<option>${esc(l)}</option>`).join('');
  cat.value = param('cat') || '';
  const draw = () => {
    const t = q.value.trim().toLowerCase();
    const r = cs.filter(c => (!t || (c.name + ' ' + c.description).toLowerCase().includes(t)) && (!cat.value || c.category === cat.value) && (!lv.value || c.skill_level === lv.value));
    g.innerHTML = r.length ? r.map(card).join('') : empty('No courses match your search.');
    $('#count').textContent = r.length + ' course(s)';
  };
  [q, cat, lv].forEach(e => e.addEventListener('input', draw));
  draw();
}

async function details() {
  const slug = param('slug'), box = $('#detail');
  const { data: c } = await sb.from('courses').select('*').eq('slug', slug || '').eq('is_published', true).maybeSingle();
  if (!c) { box.innerHTML = empty('Course not found. <a href="courses.html">Browse all courses</a>'); return; }
  document.title = c.name + ' | CTECH Cloud Academy';
  const cur = Array.isArray(c.curriculum) && c.curriculum.length ? `<ul>${c.curriculum.map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : '<p>Curriculum overview to be published.</p>';
  box.innerHTML = `<span class="chip">${esc(c.category)}</span><h1>${esc(c.name)}</h1><p class="sub">${esc(c.description)}</p><div class="grid"><div class="card"><h3>Duration</h3><p>${esc(c.duration)}</p></div><div class="card"><h3>Delivery</h3><p>${esc(c.delivery_mode)}</p></div><div class="card"><h3>Level</h3><p>${esc(c.skill_level)}</p></div><div class="card"><h3>Fee</h3>${priceHtml(c)}</div></div><div class="card" style="margin-top:20px"><h3>Curriculum overview</h3>${cur}<h3 style="margin-top:14px">Prerequisites</h3><p>${esc(c.prerequisites)}</p><h3 style="margin-top:14px">Projects</h3><p>${esc(c.projects)}</p></div><div class="btns"><a class="btn btn-primary" href="${link('enroll.html', 'course', c.id)}">Enroll Now</a><a class="btn btn-ghost" href="courses.html">Back to courses</a></div>`;
}

export const init = p => ({ index, courses: list, 'course-details': details }[p]());