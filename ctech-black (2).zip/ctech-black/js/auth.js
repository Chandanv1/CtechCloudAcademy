import { sb, getUser, configured } from './supabase.js';
import { $, toast, setLoading, showMsg, param } from './main.js';
import { fetchCourses } from './courses.js';

const emailOk = v => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v);
const phoneOk = v => /^(\+91)?[6-9]\d{9}$/.test(v.replace(/[\s-]/g, ''));
function strength(p) {
  let s = 0;
  if (p.length >= 8) s++;
  if (/[A-Z]/.test(p) && /[a-z]/.test(p)) s++;
  if (/\d/.test(p)) s++;
  if (/[^A-Za-z0-9]/.test(p)) s++;
  return s;
}
const safeNext = n => (n && /^[a-z-]+\.html(\?[\w=&%.-]*)?$/.test(n) ? n : 'dashboard.html');
const needCfg = msg => {
  if (!configured) { showMsg(msg, 'Supabase is not configured yet. Add your URL and anon key in js/supabase.js.', false); return true; }
};

async function register() {
  const f = $('#reg-form'), msg = $('#form-msg'), btn = $('#submit');
  try {
    const cs = await fetchCourses();
    $('#course').innerHTML += cs.map(c => `<option>${c.name.replace(/</g, '&lt;')}</option>`).join('');
  } catch { /* catalog optional */ }

  const pw = $('#password');
  pw.addEventListener('input', () => {
    const s = strength(pw.value); const m = $('#meter i');
    m.style.width = s * 25 + '%';
    m.style.background = ['#ff5a6e', '#ff5a6e', '#ffb347', '#35D5FF', '#28c878'][s];
    $('#strength-label').textContent = ['Too weak', 'Weak', 'Fair', 'Good', 'Strong'][s];
  });

  f.addEventListener('submit', async e => {
    e.preventDefault();
    if (needCfg(msg)) return;
    const v = Object.fromEntries(new FormData(f)); const errs = {};
    if (v.first_name.trim().length < 2) errs.first_name = 'Enter your first name';
    if (v.last_name.trim().length < 1) errs.last_name = 'Enter your last name';
    if (!emailOk(v.email)) errs.email = 'Enter a valid email';
    if (!phoneOk(v.phone)) errs.phone = 'Enter a valid 10-digit Indian mobile number';
    if (strength(v.password) < 3 || v.password.length < 8) errs.password = 'Use 8+ characters with upper/lower case, a number or symbol';
    if (v.password !== v.confirm) errs.confirm = 'Passwords do not match';
    if (!v.consent) errs.consent = 'You must accept the Terms and Privacy Policy';
    ['first_name', 'last_name', 'email', 'phone', 'password', 'confirm', 'consent'].forEach(k => {
      const el = $('#e-' + k); if (el) el.textContent = errs[k] || '';
    });
    if (Object.keys(errs).length) return;

    setLoading(btn, true, 'Creating account…');
    const email = v.email.trim();
    const { data, error } = await sb.auth.signUp({
      email,
      password: v.password,
      options: { data: { first_name: v.first_name.trim(), last_name: v.last_name.trim(), phone: v.phone.trim(), preferred_course: v.course, learning_mode: v.mode } }
    });
    if (error) { setLoading(btn, false); return showMsg(msg, error.message, false); }
    if (!data.session) { // log the new user in directly
      const r = await sb.auth.signInWithPassword({ email, password: v.password });
      if (r.error) {
        setLoading(btn, false);
        return showMsg(msg, 'Account created, but automatic login failed: ' + r.error.message + ' (is "Confirm email" switched off in Supabase?)', false);
      }
    }
    setLoading(btn, false);
    showMsg(msg, 'Account created! Taking you to your dashboard…', true);
    setTimeout(() => location.href = 'dashboard.html', 700);
  });
}

async function login() {
  const f = $('#login-form'), msg = $('#form-msg'), btn = $('#submit');
  if (await getUser()) return location.href = safeNext(param('next'));
  f.addEventListener('submit', async e => {
    e.preventDefault();
    if (needCfg(msg)) return;
    setLoading(btn, true, 'Signing in…');
    const { error } = await sb.auth.signInWithPassword({ email: f.email.value.trim(), password: f.password.value });
    setLoading(btn, false);
    if (error) return showMsg(msg, /confirm/i.test(error.message) ? 'Please verify your email first (check your inbox).' : 'Incorrect email or password.', false);
    location.href = safeNext(param('next'));
  });
}

async function forgot() {
  const f = $('#forgot-form'), n = $('#new-form'), msg = $('#form-msg');
  sb.auth.onAuthStateChange(ev => {
    if (ev === 'PASSWORD_RECOVERY') { f.hidden = true; n.hidden = false; $('#page-title').textContent = 'Set a new password'; }
  });
  f.addEventListener('submit', async e => {
    e.preventDefault();
    if (needCfg(msg)) return;
    const btn = $('#submit'); setLoading(btn, true);
    const { error } = await sb.auth.resetPasswordForEmail(f.email.value.trim(), { redirectTo: location.origin + '/forgot-password.html' });
    setLoading(btn, false);
    showMsg(msg, error ? error.message : 'If an account exists for that email, a reset link has been sent.', !error);
  });
  n.addEventListener('submit', async e => {
    e.preventDefault();
    const p = n.password.value;
    if (p.length < 8 || strength(p) < 3) return showMsg(msg, 'Use 8+ characters with upper/lower case and a number or symbol.', false);
    const { error } = await sb.auth.updateUser({ password: p });
    if (error) return showMsg(msg, error.message, false);
    toast('Password updated', 'success');
    setTimeout(() => location.href = 'dashboard.html', 900);
  });
}

export const init = p => ({ register, login, 'forgot-password': forgot }[p]());