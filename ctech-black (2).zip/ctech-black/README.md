# CTECH Cloud Academy

Static frontend (HTML/CSS/vanilla JS) + Supabase (Auth, Postgres, Edge Functions) + Razorpay (test mode).

## Folder structure
```
index.html courses.html ... (15 pages)   css/style.css   js/*.js
supabase/schema.sql  supabase/seed.sql   supabase/functions/{create-order,verify-payment}/index.ts
.env.example  package.json  README.md
```

## 1. Open in VS Code
Install [VS Code](https://code.visualstudio.com) and [Node.js LTS](https://nodejs.org). Unzip, then **File > Open Folder** and choose `ctech`. Open the terminal (Ctrl + `).

## 2. Install dependencies
There are none for the website itself. The Supabase CLI (for the Edge Functions) is installed in step 5.

## 3. Configure Supabase
1. Create a free project at supabase.com.
2. **Project Settings > API**: copy the Project URL and the `anon` public key into `js/supabase.js` (replace `YOUR_SUPABASE_URL` / `YOUR_SUPABASE_ANON_KEY`). Never use the service-role key there.
3. **Authentication > Providers > Email**: keep "Confirm email" on, set minimum password length to 8.
4. **Authentication > URL Configuration**: Site URL `http://localhost:3000`, and add `http://localhost:3000/login.html` and `http://localhost:3000/forgot-password.html` to Redirect URLs.

## 4. Apply the database schema
In Supabase **SQL Editor**, run `supabase/schema.sql`, then `supabase/seed.sql`.
The seeded courses use **placeholder fees (INR 10000)**. Change them in Admin > Courses.

## 5. Razorpay test credentials and Edge Functions
1. Create a Razorpay account, switch to **Test Mode**, and generate API keys (Settings > API Keys).
2. Install the CLI: `npm install -g supabase`, then `supabase login` and `supabase link --project-ref YOUR_PROJECT_REF`.
3. Set secrets (Supabase supplies `SUPABASE_URL`, `SUPABASE_ANON_KEY` and the service-role key to functions automatically):
   `supabase secrets set RAZORPAY_KEY_ID=rzp_test_xxx RAZORPAY_KEY_SECRET=xxx RAZORPAY_WEBHOOK_SECRET=choose_a_long_random_string`
4. Deploy: `supabase functions deploy create-order` and `supabase functions deploy verify-payment --no-verify-jwt`
   (`verify-payment` checks the user token or the Razorpay signature itself, because Razorpay's webhook has no Supabase token).
5. In Razorpay **Settings > Webhooks** add `https://YOUR_PROJECT_REF.supabase.co/functions/v1/verify-payment`, use the same webhook secret, and enable `payment.captured`, `order.paid` and `payment.failed`.

`.env.example` lists the variable names for reference. Keep real values out of the frontend and out of GitHub.

## 6. Start the local server
```
npm start
```
Open http://localhost:3000. Do not open the HTML files directly (file://): auth redirects and payments need an HTTP origin.

## 7. Register and log in as a student
Register, click the verification link in the email, then log in. You land on the dashboard.

## 8. Test enrollment and payment
Open a course > Enroll Now > Pay. Use Razorpay test cards/UPI from Razorpay's docs. After success you see a confirmation, and the dashboard shows the enrollment as `paid`. If the keys are missing you will see a clear "not configured" message; no payment is simulated.

## 9. Make an admin
Register normally, then run in the SQL Editor (replace the email):
```sql
update public.profiles set role='admin' where id=(select id from auth.users where email='you@example.com');
```
Log out and in, then open `admin.html`. Admin rights come from the database role plus RLS, not from anything editable in the browser.

## 10. Troubleshooting
- **Yellow "Development mode" banner**: `js/supabase.js` still has placeholder values.
- **"Invalid login credentials"**: email not verified yet, or wrong password.
- **Verification link goes to the wrong URL**: fix the Site URL/Redirect URLs (step 3).
- **Admin page says Access denied**: the SQL in step 9 has not been run for that user.
- **Payment error "not configured"**: secrets not set or functions not deployed (step 5).
- **Course list empty**: run `seed.sql` and make sure courses are published.
- **Port in use**: `npx serve . -l 3001`.

## Still to configure (not active until you do)
Supabase project, Razorpay keys, webhook, real course fees and content, academy contact details (`CONFIG` in `js/main.js`), real instructor/testimonial/statistics content, legal text review, and a refund policy.
