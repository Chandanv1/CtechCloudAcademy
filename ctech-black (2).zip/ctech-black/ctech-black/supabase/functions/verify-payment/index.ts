import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, content-type, x-razorpay-signature" };
const json = (b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { ...cors, "Content-Type": "application/json" } });

async function hmac(secret: string, msg: string) {
  const k = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = new Uint8Array(await crypto.subtle.sign("HMAC", k, new TextEncoder().encode(msg)));
  return [...sig].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function safeEq(a: string, b: string) {
  if (a.length !== b.length) return false;
  let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

// Marks payment paid exactly once; safe to call from both checkout and webhook.
async function markPaid(admin: any, orderId: string, paymentId: string) {
  const { data: p } = await admin.from("payments").select("id,enrollment_id,status").eq("razorpay_order_id", orderId).single();
  if (!p) return false;
  if (p.status === "paid") return true; // idempotent
  await admin.from("payments").update({ status: "paid", razorpay_payment_id: paymentId }).eq("id", p.id).neq("status", "paid");
  await admin.from("enrollments").update({ status: "paid" }).eq("id", p.enrollment_id);
  return true;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const webhookSig = req.headers.get("x-razorpay-signature");

  // Webhook path: verify against the RAW body
  if (webhookSig) {
    const secret = Deno.env.get("RAZORPAY_WEBHOOK_SECRET");
    if (!secret) return json({ error: "Webhook secret not configured" }, 503);
    const raw = await req.text();
    if (!safeEq(await hmac(secret, raw), webhookSig)) return json({ error: "Bad signature" }, 400);
    const ev = JSON.parse(raw);
    const pay = ev.payload?.payment?.entity;
    if (ev.event === "payment.captured" || ev.event === "order.paid") {
      const orderId = pay?.order_id ?? ev.payload?.order?.entity?.id;
      await markPaid(admin, orderId, pay?.id);
    } else if (ev.event === "payment.failed" && pay?.order_id) {
      await admin.from("payments").update({ status: "failed" }).eq("razorpay_order_id", pay.order_id).eq("status", "created");
    }
    return json({ ok: true });
  }

  // Checkout-callback path: requires logged-in user who owns the order
  const secret = Deno.env.get("RAZORPAY_KEY_SECRET");
  if (!secret) return json({ error: "Razorpay credentials are not configured" }, 503);
  const authed = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } } });
  const { data: { user } } = await authed.auth.getUser();
  if (!user) return json({ error: "Not authenticated" }, 401);

  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = await req.json().catch(() => ({}));
  if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) return json({ error: "Missing fields" }, 400);
  const { data: own } = await admin.from("payments").select("id").eq("razorpay_order_id", razorpay_order_id).eq("user_id", user.id).maybeSingle();
  if (!own) return json({ error: "Order not found" }, 404);
  if (!safeEq(await hmac(secret, `${razorpay_order_id}|${razorpay_payment_id}`), razorpay_signature)) return json({ error: "Signature verification failed" }, 400);

  await markPaid(admin, razorpay_order_id, razorpay_payment_id);
  return json({ ok: true, transaction_ref: razorpay_payment_id });
});
