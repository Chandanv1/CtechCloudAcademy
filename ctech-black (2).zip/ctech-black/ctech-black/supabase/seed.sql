-- Placeholder catalog. Fees (INR 10000) are PLACEHOLDERS: edit them in Admin > Courses.
insert into public.courses (slug,name,category,description,duration,delivery_mode,skill_level,prerequisites,projects,fee_inr,is_published)
select trim(both '-' from lower(regexp_replace(name,'[^a-zA-Z0-9]+','-','g'))), name, cat,
 'Course description to be added by the academy.', '[Duration to be confirmed]', 'Online / Offline', 'Beginner to Intermediate',
 'To be confirmed', 'Hands-on project details to be confirmed', 10000, true
from (values
('Data Engineering','Azure Data Engineering'),('Data Engineering','AWS Data Engineering'),('Data Engineering','Databricks'),
('Data Engineering','Apache Spark and PySpark'),('Data Engineering','SQL and Advanced SQL'),('Data Engineering','Data Warehousing'),
('Data Engineering','ETL/ELT Pipelines'),('Data Engineering','Microsoft Fabric'),
('Data Analytics','Data Analytics with Excel'),('Data Analytics','SQL for Data Analytics'),('Data Analytics','Power BI'),
('Data Analytics','Python for Data Analytics'),('Data Analytics','Tableau'),('Data Analytics','Business Intelligence'),
('Cloud Computing','Azure Fundamentals'),('Cloud Computing','Azure Administrator'),('Cloud Computing','Azure Data Services'),
('Cloud Computing','AWS Cloud Fundamentals'),('Cloud Computing','AWS Solutions Architecture'),('Cloud Computing','Cloud Security'),
('Cloud Computing','DevOps and CI/CD'),('Cloud Computing','Kubernetes and Docker'),
('AI & Machine Learning','Python Programming'),('AI & Machine Learning','Machine Learning'),('AI & Machine Learning','Artificial Intelligence'),
('AI & Machine Learning','Generative AI Fundamentals'),('AI & Machine Learning','Data Science'),
('Full-Stack & Technology Stacks','HTML, CSS and JavaScript'),('Full-Stack & Technology Stacks','React'),
('Full-Stack & Technology Stacks','Python Development'),('Full-Stack & Technology Stacks','Java Development'),
('Full-Stack & Technology Stacks','Node.js and APIs'),('Full-Stack & Technology Stacks','SQL and Database Development'),
('Full-Stack & Technology Stacks','.NET Development')
) v(cat,name)
on conflict (slug) do nothing;
