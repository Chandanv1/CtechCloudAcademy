import { sb, getUser, requireAuth } from './supabase.js';
import { $, esc, inr, param, toast } from './main.js';
const loadScript = src => new Promise((res, rej) => { if ($(`script[src="${src}"]`)) return res(); const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = () => rej(new Error('Could not load Razorpay checkout')); document.head.append(s); });
async function invoke(fn, body) {
  const { data, error } = await sb.functions.invoke(fn, { body });
  if (error) { let m = error.message; try { m = (await error.context.json()).error || m; } catch { /* ignore */ } throw new Error(m); }
  return data;
}
export async function startPayment(courseId, mode) {
  const o = await invoke('create-order', { course_id: courseId, learning_mode: mode }); // price is calculated server-side
  await loadScript('https://checkout.razorpay.com/v1/checkout.js');
  const user = await getUser();
  const rzp = new window.Razorpay({
    key: o.key_id, amount: o.amount, currency: o.currency, order_id: o.order_id, name: 'CTECH Cloud Academy', description: o.course_name,
    prefill: { email: user.email }, theme: { color: '#1687FF' },
    handler: async r => { try { const v = await invoke('verify-payment', r); location.href = 'payment-success.html?ref=' + encodeURIComponent(v.transaction_ref); } catch { location.href = 'payment-failed.html?reason=verify'; } },
    modal: { ondismiss: () => toast('Checkout closed. You can retry any time.', 'info') }
  });
  rzp.on('payment.failed', () => { location.href = 'payment-failed.html?reason=failed'; });
  rzp.open();
}
export async function init(p) {
  if (p === 'payment-failed') { $('#reason').textContent = param('reason') === 'verify' ? 'We could not verify your payment. If money was deducted, it will be reconciled automatically or contact us with your details.' : 'Your payment was not completed. No enrollment has been confirmed.'; return; }
  await requireAuth(); const ref = param('ref'), box = $('#receipt');
  const { data: pay } = await sb.from('payments').select('*,enrollments(courses(name))').eq('razorpay_payment_id', ref || '').maybeSingle();
  if (!pay) { box.innerHTML = '<p class="empty">We could not find this transaction yet.</p>'; return; }
  box.innerHTML = pay.status === 'paid'
    ? `<h2>Payment confirmed ✅</h2><p>Course: <b>${esc(pay.enrollments?.courses?.name)}</b></p><p>Amount: <b>${inr(pay.amount_paise / 100)}</b></p><p>Transaction reference: <b>${esc(pay.razorpay_payment_id)}</b></p><div class="btns"><a class="btn btn-primary" href="dashboard.html">Go to dashboard</a></div>`
    : '<h2>Payment verification pending</h2><p>Your payment is being confirmed. Refresh in a minute or check your dashboard.</p><div class="btns"><a class="btn btn-primary" href="dashboard.html">Go to dashboard</a></div>';
}
