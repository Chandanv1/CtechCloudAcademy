// Fill in your PUBLIC Supabase values (Project Settings > API). Never put the service-role or Razorpay secret here.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4';
export const SUPABASE_URL = 'YOUR_SUPABASE_URL';
export const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';
export const configured = !SUPABASE_URL.startsWith('YOUR_') && !SUPABASE_ANON_KEY.startsWith('YOUR_');
export const sb = createClient(configured ? SUPABASE_URL : 'https://placeholder.supabase.co', configured ? SUPABASE_ANON_KEY : 'placeholder', { auth: { persistSession: true, autoRefreshToken: true } });
export async function getUser() { const { data } = await sb.auth.getSession(); return data.session?.user || null; }
export async function getProfile(id) { const { data } = await sb.from('profiles').select('*').eq('id', id).single(); return data; }
export async function requireAuth() {
  const u = await getUser();
  if (!u) { location.href = 'login.html?next=' + encodeURIComponent(location.pathname.split('/').pop() + location.search); return new Promise(() => {}); }
  return u;
}
